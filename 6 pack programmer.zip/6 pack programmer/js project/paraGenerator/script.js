let c = document.getElementById("tNum");
let d = document.querySelector('.container')

let a;
const gen = (n) => {
    const f = 'abcdefghijklmnopqrstuvwxyz';
    let text = ''

    for (let i = 0; i < n; ++i) {
        let r = (Math.random() * 25).toFixed(0);
        text += f[r];
    }
    return text;
};

// console.log(gen(19));

const getNum = () => {
    a = Number(c.value);
    let data = "";
    const para = document.createElement("p");
    //for loop
    for (let i = 0; i < a; i++) {
        const r = (Math.random() * 15).toFixed(0);
        data += gen(r) +" ";
    }

    para.innerText = data;
    para.setAttribute("class", "paras");
    d.append(para);
};