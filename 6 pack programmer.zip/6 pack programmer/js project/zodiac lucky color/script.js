const zodiac = document.getElementById("zodiac");
const body = document.body;



const changeBack = ()=>{
    // console.log(zodiac.value)
    switch (zodiac.value) {
        case "aries":
            body.style.backgroundColor = "red"
            break;
        case "gemini":
            body.style.backgroundColor = "yellow"
            break;
        case "virgo":
            body.style.backgroundColor = "blue"
            break;
        case "libra":
            body.style.backgroundColor = "purple"
            break;
        case "capricon":
            body.style.backgroundColor = "orange"
            break;
        case "leo":
            body.style.backgroundColor = "grey"
            break;
    
        case "leo":
            body.style.backgroundColor = "grey"
            break;
    
        default:
            body.style.backgroundColor="white"
            break;
    }
}